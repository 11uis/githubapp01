var app = new Vue({
    el: '#app',
    data: {
        message: 'Hello everybody!',
        // propertiy to temporary store the inputs in the inpu field from the HTML
        todo: null,
        // temporary variable to store the date of the updated tod-o
        // that has to be updated in the tod-o
        editTodo: null,
        todos: [],
    },
    // to add methods in the javascript
    methods: {
        add: function(todo) {
            // if the field is empty, do nothing
            if (!this.todoIsValid) {
                return;
            }
            this.todos.push({
                content: todo,
                finished: false,
                isEdited: false,
            });
            console.log('passed through todos.push');
            // reset the variable to null
            this.todo = null;
        },

        edit: function (todo){
            // store temporarily the text in the input field
            // in the variable editTodo
            this.editTodo = todo.content;
            todo.isEdited = true;
        },

        update: function (todo) {
            if (!this.editTodoIsValid) {
                return;
            }
            todo.content = this.editTodo;
            todo.isEdited = false;
            // set editTodo to null so the editTodoIsValid is false again
            this.editTodo = null;
        },

        remove: function(todo) {
            this.todos = this.todos.filter((item) => {
               return item !== todo;
            });
            console.log(todo);
        },
    },

    computed: {
        todoIsValid() {
            return !!this.todo;
            },
        editTodoIsValid () {
            // Double exclamation means:
            // it will return if the editTodo has any content
            return !!this.editTodo;
        },

        // do not allow more thant 1 tod-o to be edited
        isBeingEdited () {
            /*   return this.todos
                   .filter(() => {
                       return todo => todo.isEdited;
                   })
                   .lenght > 0;
           },*/
            return this.todos
                .filter(todo => todo.isEdited)
                .length > 0;
        },
    },
});